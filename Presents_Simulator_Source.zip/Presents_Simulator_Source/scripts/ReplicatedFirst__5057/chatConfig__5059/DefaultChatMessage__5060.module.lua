--	// FileName: DefaultChatMessage.lua
--	// Written by: TheGamer101
-- // Forked and modified by: Jumpathy
--	// Description: Create a message label for a standard chat message.

local clientChatModules = script.Parent.Parent
local ChatSettings = require(clientChatModules:WaitForChild("ChatSettings"))
local ChatConstants = require(clientChatModules:WaitForChild("ChatConstants"))
local util = require(script.Parent:WaitForChild("Util"))
local applyRainbowGradient = require(script:WaitForChild("Rainbow"))

function CreateMessageLabel(messageData, channelName)
	local fromSpeaker = messageData.FromSpeaker
	local speakerName

	if ChatSettings.PlayerDisplayNamesEnabled and messageData.SpeakerDisplayName then
		speakerName = messageData.SpeakerDisplayName
	else
		speakerName = fromSpeaker
	end

	local message = messageData.Message

	local extraData = messageData.ExtraData or {}
	local useFont = extraData.Font or ChatSettings.DefaultFont
	local useTextSize = extraData.TextSize or ChatSettings.ChatWindowTextSize
	local useNameColor = extraData.NameColor or ChatSettings.DefaultNameColor
	local useChatColor = extraData.ChatColor or ChatSettings.DefaultMessageColor
	local useChannelColor = extraData.ChannelColor or useChatColor
	local tags = extraData.Tags or {}
	
	if(extraData.IsRainbowName) then
		useNameColor = Color3.fromRGB(255,255,255);
	end
	
	local formatUseName = string.format("[%s]:", speakerName)
	local speakerNameSize = util:GetStringTextBounds(formatUseName, useFont, useTextSize)
	local numNeededSpaces = util:GetNumberOfSpaces(formatUseName, useFont, useTextSize) + 1

	local BaseFrame, BaseMessage = util:CreateBaseMessage("", useFont, useTextSize, useChatColor)
	local NameButton = util:AddNameButtonToBaseMessage(BaseMessage, useNameColor, formatUseName, fromSpeaker)
	local ChannelButton = nil
	if(extraData.IsRainbowName) then
		local gradient = Instance.new("UIGradient");
		gradient.Parent = NameButton;
		gradient.Name = "RainbowGradient";
		applyRainbowGradient(gradient);
	end
	if(extraData.IsRainbowText) then
		local gradient = Instance.new("UIGradient");
		gradient.Parent = BaseMessage;
		gradient.Name = "RainbowGradient";
		applyRainbowGradient(gradient);
	end
	local guiObjectSpacing = UDim2.new(0, 0, 0, 0)

	if channelName ~= messageData.OriginalChannel then
			local formatChannelName = string.format("{%s}", messageData.OriginalChannel)
			ChannelButton = util:AddChannelButtonToBaseMessage(BaseMessage, useChannelColor, formatChannelName, messageData.OriginalChannel)
			guiObjectSpacing = UDim2.new(0, ChannelButton.Size.X.Offset + util:GetStringTextBounds(" ", useFont, useTextSize).X, 0, 0)
			numNeededSpaces = numNeededSpaces + util:GetNumberOfSpaces(formatChannelName, useFont, useTextSize) + 1
	end

	local tagLabels = {}
	local isImage = {}
	local images = {};
	
	for i, tag in pairs(tags) do
		local tagColor = tag.TagColor or Color3.fromRGB(255, 0, 255)
		local tagText = tag.TagText or "???"
		local formatTagText;
		if(tag.Image) then
			formatTagText = string.format("%s ", tagText)
		else
			formatTagText = string.format("[%s] ", tagText)
		end
		local label = util:AddTagLabelToBaseMessage(BaseMessage, tagColor, formatTagText)
		label.Position = guiObjectSpacing

		numNeededSpaces = numNeededSpaces + util:GetNumberOfSpaces(formatTagText, useFont, useTextSize)
		guiObjectSpacing = guiObjectSpacing + UDim2.new(0, label.Size.X.Offset, 0, 0)

		table.insert(tagLabels,label)
		table.insert(isImage,tag.Image ~= nil);
		local gradient;
		if(tag.Rainbow) then
			gradient = Instance.new("UIGradient");
			gradient.Parent = label;
			gradient.Name = "RainbowGradient";
			applyRainbowGradient(gradient);
		end
		if(tag.Image) then
			local imgLabel = Instance.new("ImageLabel");
			imgLabel.Image = tag.Image;
			imgLabel.Name = "Image";
			imgLabel.Parent = label;
			imgLabel.Size = UDim2.fromScale(1,1);
			imgLabel.BorderSizePixel = 0;
			imgLabel.BackgroundTransparency = 1;
			label.TextTransparency = 1;
			local ratio = Instance.new("UIAspectRatioConstraint");
			ratio.Parent = imgLabel;
			ratio.AspectRatio = 1;
			if(tag.Rainbow) then
				gradient.Parent = imgLabel;
			end
			table.insert(images,imgLabel);
		end
	end

	NameButton.Position = guiObjectSpacing

	local function UpdateTextFunction(messageObject)
		if messageData.IsFiltered then
			BaseMessage.Text = string.rep(" ", numNeededSpaces) .. messageObject.Message
		else
			local messageLength = messageObject.MessageLengthUtf8 or messageObject.MessageLength
			BaseMessage.Text = string.rep(" ", numNeededSpaces) .. string.rep("_", messageLength)
		end
	end

	UpdateTextFunction(messageData)

	local function GetHeightFunction(xSize)
		return util:GetMessageHeight(BaseMessage, BaseFrame, xSize)
	end

	local FadeParmaters = {}
	FadeParmaters[NameButton] = {
		TextTransparency = {FadedIn = 0, FadedOut = 1},
		TextStrokeTransparency = {FadedIn = 0.9, FadedOut = 1}
	}

	FadeParmaters[BaseMessage] = {
		TextTransparency = {FadedIn = 0, FadedOut = 1},
		TextStrokeTransparency = {FadedIn = 0.9, FadedOut = 1}
	}

	for i, tagLabel in pairs(tagLabels) do
		local index = string.format("Tag%d", i)
		FadeParmaters[tagLabel] = {
			TextTransparency = {FadedIn = (isImage[i] and 1 or 0), FadedOut = 1},
			TextStrokeTransparency = {FadedIn = 0.9, FadedOut = 1}
		}
	end
	
	for i,image in pairs(images) do
		FadeParmaters[image] = {
			ImageTransparency = {FadedIn = 0, FadedOut = 1},
		}
	end

	if ChannelButton then
		FadeParmaters[ChannelButton] = {
			TextTransparency = {FadedIn = 0, FadedOut = 1},
			TextStrokeTransparency = {FadedIn = 0.9, FadedOut = 1}
		}
	end

	local FadeInFunction, FadeOutFunction, UpdateAnimFunction = util:CreateFadeFunctions(FadeParmaters)

	return {
		[util.KEY_BASE_FRAME] = BaseFrame,
		[util.KEY_BASE_MESSAGE] = BaseMessage,
		[util.KEY_UPDATE_TEXT_FUNC] = UpdateTextFunction,
		[util.KEY_GET_HEIGHT] = GetHeightFunction,
		[util.KEY_FADE_IN] = FadeInFunction,
		[util.KEY_FADE_OUT] = FadeOutFunction,
		[util.KEY_UPDATE_ANIMATION] = UpdateAnimFunction
	}
end

return {
	[util.KEY_MESSAGE_TYPE] = ChatConstants.MessageTypeDefault,
	[util.KEY_CREATOR_FUNCTION] = CreateMessageLabel
}
