local area = workspace.areas.area6;

local getMountains = function()
	local ret = {};
	for _,object in pairs(area:GetChildren()) do
		if(object.Name == "Mountain") then
			table.insert(ret,object);
		end
	end
	return ret;
end

local getTop = function()
	local ret = {};
	for _,mountain in pairs(getMountains()) do
		for _,child in pairs(mountain:GetChildren()) do
			if(child:FindFirstChildOfClass("Texture")) then
				table.insert(ret,child);
			end
		end
	end
	return ret;
end

local applyToChildren = function(parent,properties)
	for _,child in pairs(parent:GetChildren()) do
		for property,value in pairs(properties) do
			child[property] = value;
		end
	end
end

for _,top in pairs(getTop()) do
	applyToChildren(top,{
		Texture = "rbxassetid://5975670581",
		["Color3"] = Color3.fromRGB(0,0,0)
	})
end