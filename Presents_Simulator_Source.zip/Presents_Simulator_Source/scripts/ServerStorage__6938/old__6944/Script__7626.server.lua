local p = game.Selection:Get()[1]; 
local s = p.Size; 
local f = 3/4; 
local v = Vector3.new(s.X*f,s.Y*f,s.Z*f); p.Size = v;