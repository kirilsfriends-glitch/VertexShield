# Разбор систем и зависимостей

По коду цикл игры: игрок наносит урон подаркам лучевым инструментом, получает ресурсы, использует рюкзак и зону продажи; прогресс дополняют улучшения инструментов, питомцы из яиц и rebirth. Это вывод из статического чтения скриптов, а не результат запуска.

## Основные точки входа

| ID | Объект | Назначение |
|---|---|---|
| 6780 | `game / ServerScriptService / game` | Главный серверный Script: состояние игроков, продажа, множители и координация игровых систем. |
| 6820 | `game / ServerScriptService / game / core / presents` | Генерация подарков, здоровье, награды, оформление и области появления. |
| 6900 | `game / ServerScriptService / game / logic / raygun` | Серверная логика лучевого инструмента: выбор подарка, урон и награды. |
| 6902 | `game / ServerScriptService / game / logic / present` | Логика здоровья подарка и шкалы здоровья. |
| 6895 | `game / ServerScriptService / game / config` | Цены и ёмкость рюкзаков, PassId бесконечного рюкзака, версии данных. |
| 6917 | `game / ServerScriptService / game / data` | Слой сохранения и загрузки данных игроков, события профиля. |
| 6896 | `game / ServerScriptService / game / stats` | Отображение статистики и работа с сохранёнными значениями. |
| 6832 | `game / ServerScriptService / game / core / player / shops / backpacks` | Магазин рюкзаков. |
| 6833 | `game / ServerScriptService / game / core / player / shops / rayguns` | Магазин и выдача инструментов. |
| 6835 | `game / ServerScriptService / game / core / player / pets / playerPets` | Питомцы игрока. |
| 6836 | `game / ServerScriptService / game / core / player / pets / purchasing` | Покупка яиц и выбор питомцев. |
| 6939 | `game / ServerStorage / petBase` | База питомцев. |
| 5116 | `game / StarterPlayer / StarterPlayerScripts / ui / run` | Основной клиентский интерфейс. |
| 5127 | `game / StarterPlayer / StarterPlayerScripts / core / game` | Основная клиентская игровая логика. |
| 6940 | `game / ServerStorage / game` | Клиентский скрипт-шаблон в ServerStorage. |
| 16940 | `game / ReplicatedStorage / shared / network` | Сетевой модуль. |
| 17087 | `game / ReplicatedStorage / config` | Настройки rebirth и пользовательского интерфейса. |
| 16956 | `game / ReplicatedStorage / shared / config` | Список game pass ID. |
| 6837 | `game / ServerScriptService / game / core / marketplace` | Серверная обработка покупок. |
| 6838 | `game / ServerScriptService / game / core / marketplace / gamepasses` | Игровые пропуски. |
| 6876 | `game / ServerScriptService / game / analytics / connect` | Подключение аналитики PlayFab. |
| 6937 | `game / ServerScriptService / game / rbxProxy / init` | Вход через внешний Roblox-прокси; содержит захардкоженный cookie. |
| 6892 | `game / ServerScriptService / game / analytics / primary / PlayFabSettings` | Настройки PlayFab; содержит захардкоженный devSecretKey. |
| 6785 | `game / ServerScriptService / game / external / HD / Settings / Loader` | Загрузчик внешнего HD Admin. |
| 6808 | `game / ServerScriptService / game / external / BetterChat V3 / Config / Loader` | Загрузчик внешнего BetterChat. |

## Что проверить перед запуском своей копии

- ID 6785 загружает модуль `7516711627` (HD Admin). Его реализация отсутствует в плейсе.
- ID 6808 в обычном режиме загружает `9375790695` (BetterChat). В режиме разработки ожидает `ServerScriptService.MainModule`.
- ID 6937 загружает `7721972330`, обращается к `robloxprxy.glitch.me` и передаёт сохранённый cookie в login. Не запускайте эту интеграцию с чужим cookie. Это конкретная найденная зависимость, не доказательство вредоносности всего проекта.
- ID 6892 содержит PlayFab titleId и devSecretKey, ID 6876 подключает аналитику. Их нужно заменить собственными настройками либо отдельно отключить интеграцию с проверкой её потребителей.
- Game pass и product ID относятся к исходной игре. Проверьте ID 16956, 6895, 6837, 6838 и другие обращения к MarketplaceService; для своей игры создайте собственные товары.
- Данные используют DataStore/ProfileService. Настройки сохранения находятся в ID 6895, 6917, 6918, 6896–6898. Доступ к сервисам и права ресурсов проверяйте в своей тестовой копии.
- ID 4 содержит `script.Parent:Destroy()` и удаляет родительский Baseplate. Он присутствует в оригинале и не был добавлен при экспорте.
- В ServerStorage есть каталог old и множество одинаковых Source. Все экземпляры сохранены: одинаковый текст не означает, что объект можно удалить без анализа его использования.

## Проверка извлечения

Прочитаны все бинарные блоки, проверены размеры распакованных блоков. Число INST совпадает с заголовком: 17 725 объектов, 131 класс. Для каждого из 450 Script/LocalScript/ModuleScript обнаружено свойство Source, восстановлен путь родителей и записан файл. Размер и SHA-256 файла сверены с извлечённым Source. 222 различных текста Source, 228 повторов сверх первых экземпляров. Пустой Source у ID 6812 сохранён. Исходный `.rbxl` скопирован без изменений.

Это проверка полноты экспорта, не тест игровой логики или совместимости с текущим Roblox Studio. Исходные скрипты не запускались. Реестр свойств в objects.json ограничен Name, ClassName, родителем и отдельными свойствами скриптов; остальные свойства сохраняются в оригинальном плейсе.
